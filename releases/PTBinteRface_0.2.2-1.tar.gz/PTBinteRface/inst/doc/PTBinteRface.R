## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
# install.packages("PTBinteRface", repos = c('https://ku-awdc.r-universe.dev', 'https://cloud.r-project.org'))

## ----eval=FALSE---------------------------------------------------------------
# install.packages("PTBinteRface", repos = c('https://ku-awdc.github.io/drat/', 'https://cloud.r-project.org'))

## -----------------------------------------------------------------------------
library("PTBinteRface")
results <- run_ptb_model()

## -----------------------------------------------------------------------------
results

