# PTBinteRface
Interface to the paratuberculosis model contained in the PTBinraeR package
