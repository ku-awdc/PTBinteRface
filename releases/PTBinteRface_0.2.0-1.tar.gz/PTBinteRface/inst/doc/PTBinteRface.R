## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
# install.packages("PTBinteRface", repos = c('https://ku-awdc.r-universe.dev', 'https://cloud.r-project.org'))

## ----eval=FALSE---------------------------------------------------------------
# install.packages("PTBinteRface", repos=c(CRAN="https://cran.rstudio.com/", "ku-awdc"="https://ku-awdc.github.io/drat/"))

## -----------------------------------------------------------------------------
library("PTBinteRface")
results <- run_ptb_model()

## -----------------------------------------------------------------------------
results

